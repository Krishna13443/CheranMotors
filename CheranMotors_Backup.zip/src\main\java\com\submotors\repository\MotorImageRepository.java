package com.submotors.repository;

import com.submotors.model.MotorImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MotorImageRepository extends JpaRepository<MotorImage, Long> {
    List<MotorImage> findByMotorIdOrderByDisplayOrderAsc(Long motorId);

    void deleteByMotorId(Long motorId);
}
