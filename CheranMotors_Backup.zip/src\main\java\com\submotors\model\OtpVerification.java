package com.submotors.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "otp_verifications")
public class OtpVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "mobile_number", nullable = false)
    private String mobileNumber;

    @Column(name = "otp_code", nullable = false)
    private String otpCode;

    @Column(name = "user_type", nullable = false)
    @Enumerated(EnumType.STRING)
    private UserType userType;

    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;

    @Column(name = "is_used")
    private Boolean isUsed = false;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "attempts")
    private Integer attempts = 0;

    public OtpVerification() {
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (isUsed == null)
            isUsed = false;
        if (attempts == null)
            attempts = 0;
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expiresAt);
    }

    public enum UserType {
        ADMIN, BUYER
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getOtpCode() {
        return otpCode;
    }

    public void setOtpCode(String otpCode) {
        this.otpCode = otpCode;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(LocalDateTime expiresAt) {
        this.expiresAt = expiresAt;
    }

    public Boolean getIsUsed() {
        return isUsed;
    }

    public void setIsUsed(Boolean isUsed) {
        this.isUsed = isUsed;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getAttempts() {
        return attempts;
    }

    public void setAttempts(Integer attempts) {
        this.attempts = attempts;
    }

    // Builder
    public static OtpVerificationBuilder builder() {
        return new OtpVerificationBuilder();
    }

    public static class OtpVerificationBuilder {
        private String mobileNumber;
        private String otpCode;
        private UserType userType;
        private LocalDateTime expiresAt;
        private Boolean isUsed = false;
        private Integer attempts = 0;

        public OtpVerificationBuilder mobileNumber(String mobileNumber) {
            this.mobileNumber = mobileNumber;
            return this;
        }

        public OtpVerificationBuilder otpCode(String otpCode) {
            this.otpCode = otpCode;
            return this;
        }

        public OtpVerificationBuilder userType(UserType userType) {
            this.userType = userType;
            return this;
        }

        public OtpVerificationBuilder expiresAt(LocalDateTime expiresAt) {
            this.expiresAt = expiresAt;
            return this;
        }

        public OtpVerificationBuilder isUsed(Boolean isUsed) {
            this.isUsed = isUsed;
            return this;
        }

        public OtpVerificationBuilder attempts(Integer attempts) {
            this.attempts = attempts;
            return this;
        }

        public OtpVerification build() {
            OtpVerification otp = new OtpVerification();
            otp.mobileNumber = this.mobileNumber;
            otp.otpCode = this.otpCode;
            otp.userType = this.userType;
            otp.expiresAt = this.expiresAt;
            otp.isUsed = this.isUsed;
            otp.attempts = this.attempts;
            return otp;
        }
    }
}
