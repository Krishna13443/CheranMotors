package com.submotors.service;

import com.submotors.config.TwilioConfig;
import com.submotors.model.OtpVerification;
import com.submotors.repository.OtpRepository;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class OtpService {

    @Autowired
    private OtpRepository otpRepository;

    @Autowired
    private TwilioConfig twilioConfig;

    @Value("${otp.expiry.minutes:5}")
    private int otpExpiryMinutes;

    @Value("${otp.max.attempts:5}")
    private int maxAttempts;

    private final SecureRandom random = new SecureRandom();

    // In-memory store for demo mode
    private final Map<String, String> demoOtpStore = new HashMap<>();

    public String generateOtp() {
        int otp = 100000 + random.nextInt(900000); // 6-digit OTP
        return String.valueOf(otp);
    }

    @Transactional
    public Map<String, Object> sendOtp(String mobileNumber, OtpVerification.UserType userType) {
        Map<String, Object> response = new HashMap<>();

        // Rate limiting check
        long recentOtps = otpRepository.countRecentOtps(mobileNumber, LocalDateTime.now().minusHours(1));
        if (recentOtps >= maxAttempts) {
            response.put("success", false);
            response.put("message", "Too many OTP requests. Please try again later.");
            return response;
        }

        String otp = generateOtp();

        // Save OTP to database
        OtpVerification otpVerification = OtpVerification.builder()
                .mobileNumber(mobileNumber)
                .otpCode(otp)
                .userType(userType)
                .expiresAt(LocalDateTime.now().plusMinutes(otpExpiryMinutes))
                .build();
        otpRepository.save(otpVerification);

        // Try to send via Twilio, fallback to demo mode
        if (twilioConfig.isConfigured()) {
            try {
                Message message = Message.creator(
                        new PhoneNumber(mobileNumber),
                        new PhoneNumber(twilioConfig.getPhoneNumber()),
                        "Your SubMotors verification code is: " + otp + ". Valid for " + otpExpiryMinutes + " minutes.")
                        .create();

                response.put("success", true);
                response.put("message", "OTP sent successfully to " + maskMobile(mobileNumber));
                response.put("messageId", message.getSid());
            } catch (Exception e) {
                response.put("success", false);
                response.put("message", "Failed to send OTP: " + e.getMessage());
            }
        } else {
            // Demo mode - store OTP and show it in console
            demoOtpStore.put(mobileNumber, otp);
            System.out.println("===========================================");
            System.out.println("DEMO MODE - OTP for " + mobileNumber + ": " + otp);
            System.out.println("===========================================");

            response.put("success", true);
            response.put("message", "OTP sent! (Demo mode: check console for OTP)");
            response.put("demoOtp", otp); // Only for demo mode
        }

        return response;
    }

    @Transactional
    public Map<String, Object> verifyOtp(String mobileNumber, String otp, OtpVerification.UserType userType) {
        Map<String, Object> response = new HashMap<>();

        Optional<OtpVerification> otpOptional = otpRepository
                .findTopByMobileNumberAndUserTypeAndIsUsedFalseOrderByCreatedAtDesc(mobileNumber, userType);

        if (otpOptional.isEmpty()) {
            response.put("success", false);
            response.put("message", "No OTP found. Please request a new OTP.");
            return response;
        }

        OtpVerification otpVerification = otpOptional.get();

        if (otpVerification.isExpired()) {
            response.put("success", false);
            response.put("message", "OTP has expired. Please request a new one.");
            return response;
        }

        if (!otpVerification.getOtpCode().equals(otp)) {
            otpVerification.setAttempts(otpVerification.getAttempts() + 1);
            otpRepository.save(otpVerification);

            response.put("success", false);
            response.put("message", "Invalid OTP. Please try again.");
            return response;
        }

        // Mark OTP as used
        otpVerification.setIsUsed(true);
        otpRepository.save(otpVerification);

        response.put("success", true);
        response.put("message", "OTP verified successfully!");
        return response;
    }

    private String maskMobile(String mobile) {
        if (mobile.length() <= 4)
            return mobile;
        return mobile.substring(0, 3) + "****" + mobile.substring(mobile.length() - 3);
    }
}
