package com.submotors.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "buyers")
public class Buyer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "mobile_number", unique = true, nullable = false)
    private String mobileNumber;

    private String name;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "last_login")
    private LocalDateTime lastLogin;

    public Buyer() {
    }

    public Buyer(Long id, String mobileNumber, String name, LocalDateTime createdAt, LocalDateTime lastLogin) {
        this.id = id;
        this.mobileNumber = mobileNumber;
        this.name = name;
        this.createdAt = createdAt;
        this.lastLogin = lastLogin;
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        lastLogin = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        lastLogin = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(LocalDateTime lastLogin) {
        this.lastLogin = lastLogin;
    }

    // Builder
    public static BuyerBuilder builder() {
        return new BuyerBuilder();
    }

    public static class BuyerBuilder {
        private Long id;
        private String mobileNumber;
        private String name;
        private LocalDateTime createdAt;
        private LocalDateTime lastLogin;

        public BuyerBuilder id(Long id) {
            this.id = id;
            return this;
        }

        public BuyerBuilder mobileNumber(String mobileNumber) {
            this.mobileNumber = mobileNumber;
            return this;
        }

        public BuyerBuilder name(String name) {
            this.name = name;
            return this;
        }

        public BuyerBuilder createdAt(LocalDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public BuyerBuilder lastLogin(LocalDateTime lastLogin) {
            this.lastLogin = lastLogin;
            return this;
        }

        public Buyer build() {
            return new Buyer(id, mobileNumber, name, createdAt, lastLogin);
        }
    }
}
