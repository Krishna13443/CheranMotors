package com.submotors.config;

import com.twilio.Twilio;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TwilioConfig {

    @Value("${twilio.account.sid}")
    private String accountSid;

    @Value("${twilio.auth.token}")
    private String authToken;

    @Value("${twilio.phone.number}")
    private String phoneNumber;

    @PostConstruct
    public void initTwilio() {
        if (accountSid != null && !accountSid.startsWith("YOUR_")) {
            Twilio.init(accountSid, authToken);
            System.out.println("Twilio initialized successfully!");
        } else {
            System.out.println("WARNING: Twilio not configured. Using demo mode for OTP.");
        }
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public boolean isConfigured() {
        return accountSid != null && !accountSid.startsWith("YOUR_");
    }
}
