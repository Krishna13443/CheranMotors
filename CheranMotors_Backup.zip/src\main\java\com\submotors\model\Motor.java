package com.submotors.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "motors")
public class Motor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "seller_id", nullable = false)
    @JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
    private Seller seller;

    @Column(nullable = false)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "motor_type", nullable = false)
    @Enumerated(EnumType.STRING)
    private MotorType motorType;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @Column(name = "motor_condition")
    @Enumerated(EnumType.STRING)
    private MotorCondition motorCondition;

    private String brand;

    @Column(name = "power_rating")
    private String powerRating;

    private String voltage;

    private String rpm;

    private String phase;

    private String warranty;

    @Column(name = "is_approved")
    private Boolean isApproved = false;

    @Column(name = "is_pending")
    private Boolean isPending = true;

    @Column(name = "is_rejected")
    private Boolean isRejected = false;

    @Column(name = "is_sold")
    private Boolean isSold = false;

    @Column(name = "rejection_reason")
    private String rejectionReason;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "motor", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @OrderBy("displayOrder ASC")
    private List<MotorImage> images;

    public Motor() {
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (isApproved == null)
            isApproved = false;
        if (isPending == null)
            isPending = true;
        if (isRejected == null)
            isRejected = false;
        if (isSold == null)
            isSold = false;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public enum MotorType {
        NEW, REFURBISHED
    }

    public enum MotorCondition {
        EXCELLENT, GOOD, FAIR
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Seller getSeller() {
        return seller;
    }

    public void setSeller(Seller seller) {
        this.seller = seller;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MotorType getMotorType() {
        return motorType;
    }

    public void setMotorType(MotorType motorType) {
        this.motorType = motorType;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public MotorCondition getMotorCondition() {
        return motorCondition;
    }

    public void setMotorCondition(MotorCondition motorCondition) {
        this.motorCondition = motorCondition;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPowerRating() {
        return powerRating;
    }

    public void setPowerRating(String powerRating) {
        this.powerRating = powerRating;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }

    public String getRpm() {
        return rpm;
    }

    public void setRpm(String rpm) {
        this.rpm = rpm;
    }

    public String getPhase() {
        return phase;
    }

    public void setPhase(String phase) {
        this.phase = phase;
    }

    public String getWarranty() {
        return warranty;
    }

    public void setWarranty(String warranty) {
        this.warranty = warranty;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }

    public Boolean getIsPending() {
        return isPending;
    }

    public void setIsPending(Boolean isPending) {
        this.isPending = isPending;
    }

    public Boolean getIsRejected() {
        return isRejected;
    }

    public void setIsRejected(Boolean isRejected) {
        this.isRejected = isRejected;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    public Boolean getIsSold() {
        return isSold;
    }

    public void setIsSold(Boolean isSold) {
        this.isSold = isSold;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<MotorImage> getImages() {
        return images;
    }

    public void setImages(List<MotorImage> images) {
        this.images = images;
    }

    // Builder
    public static MotorBuilder builder() {
        return new MotorBuilder();
    }

    public static class MotorBuilder {
        private Seller seller;
        private String title;
        private String description;
        private MotorType motorType;
        private BigDecimal price;
        private MotorCondition motorCondition;
        private String brand;
        private String powerRating;
        private String voltage;
        private String rpm;
        private String phase;
        private String warranty;
        private Boolean isApproved = false;
        private Boolean isPending = true;
        private Boolean isRejected = false;
        private Boolean isSold = false;

        public MotorBuilder seller(Seller seller) {
            this.seller = seller;
            return this;
        }

        public MotorBuilder title(String title) {
            this.title = title;
            return this;
        }

        public MotorBuilder description(String description) {
            this.description = description;
            return this;
        }

        public MotorBuilder motorType(MotorType motorType) {
            this.motorType = motorType;
            return this;
        }

        public MotorBuilder price(BigDecimal price) {
            this.price = price;
            return this;
        }

        public MotorBuilder motorCondition(MotorCondition motorCondition) {
            this.motorCondition = motorCondition;
            return this;
        }

        public MotorBuilder brand(String brand) {
            this.brand = brand;
            return this;
        }

        public MotorBuilder powerRating(String powerRating) {
            this.powerRating = powerRating;
            return this;
        }

        public MotorBuilder voltage(String voltage) {
            this.voltage = voltage;
            return this;
        }

        public MotorBuilder rpm(String rpm) {
            this.rpm = rpm;
            return this;
        }

        public MotorBuilder phase(String phase) {
            this.phase = phase;
            return this;
        }

        public MotorBuilder warranty(String warranty) {
            this.warranty = warranty;
            return this;
        }

        public MotorBuilder isApproved(Boolean isApproved) {
            this.isApproved = isApproved;
            return this;
        }

        public MotorBuilder isPending(Boolean isPending) {
            this.isPending = isPending;
            return this;
        }

        public MotorBuilder isRejected(Boolean isRejected) {
            this.isRejected = isRejected;
            return this;
        }

        public MotorBuilder isSold(Boolean isSold) {
            this.isSold = isSold;
            return this;
        }

        public Motor build() {
            Motor motor = new Motor();
            motor.seller = this.seller;
            motor.title = this.title;
            motor.description = this.description;
            motor.motorType = this.motorType;
            motor.price = this.price;
            motor.motorCondition = this.motorCondition;
            motor.brand = this.brand;
            motor.powerRating = this.powerRating;
            motor.voltage = this.voltage;
            motor.rpm = this.rpm;
            motor.phase = this.phase;
            motor.warranty = this.warranty;
            motor.isApproved = this.isApproved;
            motor.isPending = this.isPending;
            motor.isRejected = this.isRejected;
            motor.isSold = this.isSold;
            return motor;
        }
    }
}
