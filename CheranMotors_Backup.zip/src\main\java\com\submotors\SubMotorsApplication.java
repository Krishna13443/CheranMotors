package com.submotors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubMotorsApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(SubMotorsApplication.class, args);
        System.out.println("\n========================================");
        System.out.println("   SubMotors Application Started!");
        System.out.println("   Access: http://localhost:8080");
        System.out.println("========================================\n");
    }
}
