package com.submotors.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Serve uploaded images
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:uploads/");

        // Serve static files
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/static/");
    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        // Forward routes to index.html for SPA
        registry.addViewController("/").setViewName("forward:/index.html");
        registry.addViewController("/admin").setViewName("forward:/admin.html");
        registry.addViewController("/admin/**").setViewName("forward:/admin.html");
        registry.addViewController("/seller").setViewName("forward:/seller.html");
        registry.addViewController("/seller/**").setViewName("forward:/seller.html");
        registry.addViewController("/buyer").setViewName("forward:/buyer.html");
        registry.addViewController("/buyer/**").setViewName("forward:/buyer.html");
    }
}
