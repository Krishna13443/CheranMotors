package com.submotors.repository;

import com.submotors.model.Motor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MotorRepository extends JpaRepository<Motor, Long> {

    // Approved motors for buyers
    List<Motor> findByIsApprovedTrueOrderByCreatedAtDesc();

    // Pending motors for admin review
    List<Motor> findByIsPendingTrueOrderByCreatedAtDesc();

    // Motors by seller
    List<Motor> findBySellerIdOrderByCreatedAtDesc(Long sellerId);

    // Search motors
    @Query("SELECT m FROM Motor m WHERE m.isApproved = true AND " +
            "(LOWER(m.title) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
            "LOWER(m.brand) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
            "LOWER(m.description) LIKE LOWER(CONCAT('%', :query, '%')))")
    List<Motor> searchMotors(@Param("query") String query);

    // Filter by type
    List<Motor> findByIsApprovedTrueAndMotorTypeOrderByCreatedAtDesc(Motor.MotorType motorType);

    // Count pending
    long countByIsPendingTrue();

    // Count approved
    long countByIsApprovedTrue();

    // Count by seller
    long countBySellerId(Long sellerId);
}
