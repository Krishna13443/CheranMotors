package com.submotors.repository;

import com.submotors.model.Seller;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface SellerRepository extends JpaRepository<Seller, Long> {
    Optional<Seller> findByUsername(String username);

    Optional<Seller> findByUsernameAndPassword(String username, String password);

    boolean existsByUsername(String username);

    boolean existsByMobileNumber(String mobileNumber);

    List<Seller> findByIsActiveTrue();

    List<Seller> findAllByOrderByCreatedAtDesc();
}
