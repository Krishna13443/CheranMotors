package com.submotors.service;

import com.submotors.model.Motor;
import com.submotors.model.MotorImage;
import com.submotors.model.Seller;
import com.submotors.repository.MotorImageRepository;
import com.submotors.repository.MotorRepository;
import com.submotors.repository.SellerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

@Service
public class SellerService {

    @Autowired
    private SellerRepository sellerRepository;

    @Autowired
    private MotorRepository motorRepository;

    @Autowired
    private MotorImageRepository motorImageRepository;

    private final String uploadDir = "uploads/motors/";

    public Map<String, Object> login(String username, String password) {
        Map<String, Object> response = new HashMap<>();

        Optional<Seller> sellerOpt = sellerRepository.findByUsernameAndPassword(username, password);

        if (sellerOpt.isEmpty()) {
            response.put("success", false);
            response.put("message", "Invalid username or password.");
            return response;
        }

        Seller seller = sellerOpt.get();

        if (!seller.getIsActive()) {
            response.put("success", false);
            response.put("message", "Your account has been deactivated. Please contact admin.");
            return response;
        }

        String token = UUID.randomUUID().toString();
        response.put("success", true);
        response.put("message", "Login successful!");
        response.put("token", token);
        response.put("sellerId", seller.getId());
        response.put("name", seller.getName());
        response.put("role", "SELLER");
        return response;
    }

    public Optional<Seller> getSellerById(Long id) {
        return sellerRepository.findById(id);
    }

    @Transactional
    public Map<String, Object> createMotor(Long sellerId, Map<String, Object> motorData, List<MultipartFile> images) {
        Map<String, Object> response = new HashMap<>();

        Optional<Seller> sellerOpt = sellerRepository.findById(sellerId);
        if (sellerOpt.isEmpty()) {
            response.put("success", false);
            response.put("message", "Seller not found.");
            return response;
        }

        Seller seller = sellerOpt.get();

        try {
            Motor.MotorType motorType = Motor.MotorType.valueOf(
                    motorData.get("motorType").toString().toUpperCase());
            Motor.MotorCondition condition = Motor.MotorCondition.valueOf(
                    motorData.get("condition").toString().toUpperCase());

            Motor motor = Motor.builder()
                    .seller(seller)
                    .title(motorData.get("title").toString())
                    .description(motorData.get("description").toString())
                    .motorType(motorType)
                    .motorCondition(condition)
                    .price(new BigDecimal(motorData.get("price").toString()))
                    .brand(motorData.getOrDefault("brand", "").toString())
                    .powerRating(motorData.getOrDefault("powerRating", "").toString())
                    .voltage(motorData.getOrDefault("voltage", "").toString())
                    .rpm(motorData.getOrDefault("rpm", "").toString())
                    .phase(motorData.getOrDefault("phase", "").toString())
                    .warranty(motorData.getOrDefault("warranty", "").toString())
                    .isPending(false)
                    .isApproved(true)
                    .isSold(false)
                    .build();

            motor = motorRepository.save(motor);

            // Save images
            if (images != null && !images.isEmpty()) {
                saveMotorImages(motor, images);
            }

            response.put("success", true);
            response.put("message", "Motor posted successfully! Waiting for admin approval.");
            response.put("motorId", motor.getId());

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error creating motor: " + e.getMessage());
        }

        return response;
    }

    private void saveMotorImages(Motor motor, List<MultipartFile> images) throws IOException {
        Path uploadPath = Paths.get(uploadDir + motor.getId());
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        int order = 0;
        for (MultipartFile image : images) {
            if (!image.isEmpty()) {
                String filename = UUID.randomUUID() + "_" + image.getOriginalFilename();
                Path filePath = uploadPath.resolve(filename);
                Files.copy(image.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

                MotorImage motorImage = MotorImage.builder()
                        .motor(motor)
                        .imagePath("/uploads/motors/" + motor.getId() + "/" + filename)
                        .imageName(image.getOriginalFilename())
                        .displayOrder(order++)
                        .build();
                motorImageRepository.save(motorImage);
            }
        }
    }

    public List<Motor> getMotorsBySeller(Long sellerId) {
        return motorRepository.findBySellerIdOrderByCreatedAtDesc(sellerId);
    }

    public Map<String, Object> getSellerStats(Long sellerId) {
        Map<String, Object> stats = new HashMap<>();
        List<Motor> motors = motorRepository.findBySellerIdOrderByCreatedAtDesc(sellerId);

        long total = motors.size();
        long approved = motors.stream().filter(Motor::getIsApproved).count();
        long pending = motors.stream().filter(Motor::getIsPending).count();
        long rejected = motors.stream().filter(Motor::getIsRejected).count();

        stats.put("totalMotors", total);
        stats.put("approvedMotors", approved);
        stats.put("pendingMotors", pending);
        stats.put("rejectedMotors", rejected);

        return stats;
    }

    @Transactional
    public Map<String, Object> deleteMotor(Long sellerId, Long motorId) {
        Map<String, Object> response = new HashMap<>();

        Optional<Motor> motorOpt = motorRepository.findById(motorId);
        if (motorOpt.isEmpty()) {
            response.put("success", false);
            response.put("message", "Motor not found.");
            return response;
        }

        Motor motor = motorOpt.get();
        if (!motor.getSeller().getId().equals(sellerId)) {
            response.put("success", false);
            response.put("message", "You don't have permission to delete this motor.");
            return response;
        }

        motorRepository.delete(motor);
        response.put("success", true);
        response.put("message", "Motor deleted successfully!");
        return response;
    }

    @Transactional
    public Map<String, Object> markAsSold(Long sellerId, Long motorId) {
        Map<String, Object> response = new HashMap<>();

        Optional<Motor> motorOpt = motorRepository.findById(motorId);
        if (motorOpt.isEmpty()) {
            response.put("success", false);
            response.put("message", "Motor not found.");
            return response;
        }

        Motor motor = motorOpt.get();
        if (!motor.getSeller().getId().equals(sellerId)) {
            response.put("success", false);
            response.put("message", "You don't have permission to update this motor.");
            return response;
        }

        motor.setIsSold(true);
        motorRepository.save(motor);
        response.put("success", true);
        response.put("message", "Motor marked as sold!");
        return response;
    }
}
