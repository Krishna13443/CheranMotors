package com.submotors.repository;

import com.submotors.model.OtpVerification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface OtpRepository extends JpaRepository<OtpVerification, Long> {

    Optional<OtpVerification> findTopByMobileNumberAndUserTypeAndIsUsedFalseOrderByCreatedAtDesc(
            String mobileNumber, OtpVerification.UserType userType);

    @Query("SELECT COUNT(o) FROM OtpVerification o WHERE o.mobileNumber = :mobile " +
            "AND o.createdAt > :since")
    long countRecentOtps(@Param("mobile") String mobileNumber, @Param("since") LocalDateTime since);

    void deleteByExpiresAtBefore(LocalDateTime dateTime);
}
