package com.submotors.service;

import com.submotors.model.Admin;
import com.submotors.model.OtpVerification;
import com.submotors.model.Seller;
import com.submotors.model.Motor;
import com.submotors.repository.AdminRepository;
import com.submotors.repository.SellerRepository;
import com.submotors.repository.MotorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import java.security.SecureRandom;
import java.util.*;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private SellerRepository sellerRepository;

    @Autowired
    private MotorRepository motorRepository;

    @Autowired
    private OtpService otpService;

    @Value("${admin.mobile.number}")
    private String adminMobileNumber;

    private final SecureRandom random = new SecureRandom();

    @PostConstruct
    public void initAdmin() {
        // Create default admin if not exists
        if (!adminRepository.existsByMobileNumber(adminMobileNumber)) {
            Admin admin = Admin.builder()
                    .mobileNumber(adminMobileNumber)
                    .name("System Admin")
                    .build();
            adminRepository.save(admin);
            System.out.println("Default admin created with mobile: " + adminMobileNumber);
        }
    }

    public boolean isAdminMobile(String mobileNumber) {
        String normalized = normalizeMobile(mobileNumber);
        String normalizedAdmin = normalizeMobile(adminMobileNumber);
        return normalizedAdmin.equals(normalized) ||
                adminRepository.existsByMobileNumber(mobileNumber) ||
                adminRepository.existsByMobileNumber(normalized) ||
                adminRepository.existsByMobileNumber("+91" + normalized);
    }

    private String normalizeMobile(String mobile) {
        if (mobile == null)
            return "";
        // Remove +91, 91, 0 prefix and any spaces/dashes
        String cleaned = mobile.replaceAll("[\\s\\-]", "");
        if (cleaned.startsWith("+91")) {
            cleaned = cleaned.substring(3);
        } else if (cleaned.startsWith("91") && cleaned.length() > 10) {
            cleaned = cleaned.substring(2);
        } else if (cleaned.startsWith("0")) {
            cleaned = cleaned.substring(1);
        }
        return cleaned;
    }

    public Map<String, Object> sendAdminOtp(String mobileNumber) {
        if (!isAdminMobile(mobileNumber)) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "This mobile number is not authorized as admin.");
            return response;
        }
        // Normalize for OTP sending
        String normalized = "+91" + normalizeMobile(mobileNumber);
        return otpService.sendOtp(normalized, OtpVerification.UserType.ADMIN);
    }

    public Map<String, Object> verifyAdminOtp(String mobileNumber, String otp) {
        Map<String, Object> result = otpService.verifyOtp(mobileNumber, otp, OtpVerification.UserType.ADMIN);
        if ((Boolean) result.get("success")) {
            // Generate session token
            String token = UUID.randomUUID().toString();
            result.put("token", token);
            result.put("role", "ADMIN");
        }
        return result;
    }

    // Seller Management
    @Transactional
    public Map<String, Object> createSeller(Map<String, String> sellerData) {
        Map<String, Object> response = new HashMap<>();

        String username = sellerData.get("username");
        String mobileNumber = sellerData.get("mobileNumber");

        if (sellerRepository.existsByUsername(username)) {
            response.put("success", false);
            response.put("message", "Username already exists.");
            return response;
        }

        // Generate random password
        String password = generatePassword();

        Seller seller = Seller.builder()
                .username(username)
                .password(password) // In production, hash this
                .mobileNumber(mobileNumber)
                .name(sellerData.get("name"))
                .email(sellerData.get("email"))
                .businessName(sellerData.get("businessName"))
                .address(sellerData.get("address"))
                .isActive(true)
                .build();

        sellerRepository.save(seller);

        response.put("success", true);
        response.put("message", "Seller created successfully!");
        response.put("sellerId", seller.getId());
        response.put("username", username);
        response.put("password", password);
        return response;
    }

    public List<Seller> getAllSellers() {
        return sellerRepository.findAllByOrderByCreatedAtDesc();
    }

    @Transactional
    public Map<String, Object> toggleSellerStatus(Long sellerId) {
        Map<String, Object> response = new HashMap<>();

        Optional<Seller> sellerOpt = sellerRepository.findById(sellerId);
        if (sellerOpt.isEmpty()) {
            response.put("success", false);
            response.put("message", "Seller not found.");
            return response;
        }

        Seller seller = sellerOpt.get();
        seller.setIsActive(!seller.getIsActive());
        sellerRepository.save(seller);

        response.put("success", true);
        response.put("message", seller.getIsActive() ? "Seller activated!" : "Seller deactivated!");
        response.put("isActive", seller.getIsActive());
        return response;
    }

    // Motor Management
    public List<Motor> getPendingMotors() {
        return motorRepository.findByIsPendingTrueOrderByCreatedAtDesc();
    }

    public Map<String, Object> getMotorDetails(Long motorId) {
        Map<String, Object> response = new HashMap<>();
        Optional<Motor> motorOpt = motorRepository.findById(motorId);

        if (motorOpt.isEmpty()) {
            response.put("success", false);
            response.put("message", "Motor not found.");
            return response;
        }

        Motor motor = motorOpt.get();
        response.put("success", true);
        response.put("motor", motor);
        response.put("sellerMobile", motor.getSeller().getMobileNumber());
        response.put("sellerName", motor.getSeller().getName());
        return response;
    }

    @Transactional
    public Map<String, Object> approveMotor(Long motorId) {
        Map<String, Object> response = new HashMap<>();

        Optional<Motor> motorOpt = motorRepository.findById(motorId);
        if (motorOpt.isEmpty()) {
            response.put("success", false);
            response.put("message", "Motor not found.");
            return response;
        }

        Motor motor = motorOpt.get();
        motor.setIsApproved(true);
        motor.setIsPending(false);
        motor.setIsRejected(false);
        motorRepository.save(motor);

        response.put("success", true);
        response.put("message", "Motor approved and now visible to buyers!");
        return response;
    }

    @Transactional
    public Map<String, Object> rejectMotor(Long motorId, String reason) {
        Map<String, Object> response = new HashMap<>();

        Optional<Motor> motorOpt = motorRepository.findById(motorId);
        if (motorOpt.isEmpty()) {
            response.put("success", false);
            response.put("message", "Motor not found.");
            return response;
        }

        Motor motor = motorOpt.get();
        motor.setIsApproved(false);
        motor.setIsPending(false);
        motor.setIsRejected(true);
        motor.setRejectionReason(reason);
        motorRepository.save(motor);

        response.put("success", true);
        response.put("message", "Motor rejected.");
        return response;
    }

    // Dashboard Stats
    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalSellers", sellerRepository.count());
        stats.put("activeSellers", sellerRepository.findByIsActiveTrue().size());
        stats.put("pendingMotors", motorRepository.countByIsPendingTrue());
        stats.put("approvedMotors", motorRepository.countByIsApprovedTrue());
        stats.put("totalMotors", motorRepository.count());
        return stats;
    }

    private String generatePassword() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }
}
