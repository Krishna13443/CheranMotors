package com.submotors.controller;

import com.submotors.model.Motor;
import com.submotors.service.BuyerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/buyer")
public class BuyerController {

    @Autowired
    private BuyerService buyerService;

    @PostMapping("/send-otp")
    public ResponseEntity<Map<String, Object>> sendOtp(@RequestBody Map<String, String> request) {
        String mobileNumber = request.get("mobileNumber");
        return ResponseEntity.ok(buyerService.sendOtp(mobileNumber));
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<Map<String, Object>> verifyOtp(@RequestBody Map<String, String> request) {
        String mobileNumber = request.get("mobileNumber");
        String otp = request.get("otp");
        String name = request.getOrDefault("name", "Buyer");
        return ResponseEntity.ok(buyerService.verifyOtpAndLogin(mobileNumber, otp, name));
    }

    @GetMapping("/motors")
    public ResponseEntity<List<Motor>> getMotors(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String type) {

        List<Motor> motors;

        if (search != null && !search.isEmpty()) {
            motors = buyerService.searchMotors(search);
        } else if (type != null && !type.isEmpty()) {
            motors = buyerService.filterByType(type);
        } else {
            motors = buyerService.getApprovedMotors();
        }

        return ResponseEntity.ok(motors);
    }

    @GetMapping("/motors/{id}")
    public ResponseEntity<Map<String, Object>> getMotorDetails(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        Optional<Motor> motorOpt = buyerService.getMotorDetails(id);

        if (motorOpt.isPresent()) {
            Motor motor = motorOpt.get();
            response.put("success", true);
            response.put("motor", motor);
            response.put("sellerMobile", motor.getSeller().getMobileNumber());
            response.put("sellerName", motor.getSeller().getName());
        } else {
            response.put("success", false);
            response.put("message", "Motor not found or not approved");
        }

        return ResponseEntity.ok(response);
    }
}
