package com.submotors.controller;

import com.submotors.model.Motor;
import com.submotors.model.Seller;
import com.submotors.service.SellerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/seller")
public class SellerController {

    @Autowired
    private SellerService sellerService;

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String password = request.get("password");
        return ResponseEntity.ok(sellerService.login(username, password));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getSellerInfo(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        Optional<Seller> sellerOpt = sellerService.getSellerById(id);

        if (sellerOpt.isPresent()) {
            Seller seller = sellerOpt.get();
            response.put("success", true);
            response.put("id", seller.getId());
            response.put("name", seller.getName());
            response.put("businessName", seller.getBusinessName());
            response.put("mobileNumber", seller.getMobileNumber());
            response.put("email", seller.getEmail());
        } else {
            response.put("success", false);
            response.put("message", "Seller not found");
        }

        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}/stats")
    public ResponseEntity<Map<String, Object>> getSellerStats(@PathVariable Long id) {
        return ResponseEntity.ok(sellerService.getSellerStats(id));
    }

    @GetMapping("/{id}/motors")
    public ResponseEntity<List<Motor>> getSellerMotors(@PathVariable Long id) {
        return ResponseEntity.ok(sellerService.getMotorsBySeller(id));
    }

    @PostMapping("/{id}/motors")
    public ResponseEntity<Map<String, Object>> createMotor(
            @PathVariable Long id,
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("motorType") String motorType,
            @RequestParam("condition") String condition,
            @RequestParam("price") String price,
            @RequestParam(value = "brand", required = false) String brand,
            @RequestParam(value = "powerRating", required = false) String powerRating,
            @RequestParam(value = "voltage", required = false) String voltage,
            @RequestParam(value = "rpm", required = false) String rpm,
            @RequestParam(value = "phase", required = false) String phase,
            @RequestParam(value = "warranty", required = false) String warranty,
            @RequestParam(value = "images", required = false) List<MultipartFile> images) {

        Map<String, Object> motorData = new HashMap<>();
        motorData.put("title", title);
        motorData.put("description", description);
        motorData.put("motorType", motorType);
        motorData.put("condition", condition);
        motorData.put("price", price);
        motorData.put("brand", brand);
        motorData.put("powerRating", powerRating);
        motorData.put("voltage", voltage);
        motorData.put("rpm", rpm);
        motorData.put("phase", phase);
        motorData.put("warranty", warranty);

        return ResponseEntity.ok(sellerService.createMotor(id, motorData, images));
    }

    @DeleteMapping("/{sellerId}/motors/{motorId}")
    public ResponseEntity<Map<String, Object>> deleteMotor(
            @PathVariable Long sellerId,
            @PathVariable Long motorId) {
        return ResponseEntity.ok(sellerService.deleteMotor(sellerId, motorId));
    }

    @PutMapping("/{sellerId}/motors/{motorId}/sold")
    public ResponseEntity<Map<String, Object>> markAsSold(
            @PathVariable Long sellerId,
            @PathVariable Long motorId) {
        return ResponseEntity.ok(sellerService.markAsSold(sellerId, motorId));
    }
}
