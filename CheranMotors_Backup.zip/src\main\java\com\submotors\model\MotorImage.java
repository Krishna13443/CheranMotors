package com.submotors.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "motor_images")
public class MotorImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "motor_id", nullable = false)
    @JsonIgnore
    private Motor motor;

    @Column(name = "image_path", nullable = false)
    private String imagePath;

    @Column(name = "image_name")
    private String imageName;

    @Column(name = "display_order")
    private Integer displayOrder = 0;

    public MotorImage() {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public Integer getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Integer displayOrder) {
        this.displayOrder = displayOrder;
    }

    // Builder
    public static MotorImageBuilder builder() {
        return new MotorImageBuilder();
    }

    public static class MotorImageBuilder {
        private Motor motor;
        private String imagePath;
        private String imageName;
        private Integer displayOrder = 0;

        public MotorImageBuilder motor(Motor motor) {
            this.motor = motor;
            return this;
        }

        public MotorImageBuilder imagePath(String imagePath) {
            this.imagePath = imagePath;
            return this;
        }

        public MotorImageBuilder imageName(String imageName) {
            this.imageName = imageName;
            return this;
        }

        public MotorImageBuilder displayOrder(Integer displayOrder) {
            this.displayOrder = displayOrder;
            return this;
        }

        public MotorImage build() {
            MotorImage img = new MotorImage();
            img.motor = this.motor;
            img.imagePath = this.imagePath;
            img.imageName = this.imageName;
            img.displayOrder = this.displayOrder;
            return img;
        }
    }
}
