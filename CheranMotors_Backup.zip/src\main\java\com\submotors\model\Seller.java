package com.submotors.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "sellers")
public class Seller {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(name = "mobile_number", nullable = false)
    private String mobileNumber;

    @Column(nullable = false)
    private String name;

    private String email;

    @Column(name = "business_name")
    private String businessName;

    private String address;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @OneToMany(mappedBy = "seller", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private List<Motor> motors;

    public Seller() {
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (isActive == null)
            isActive = true;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public List<Motor> getMotors() {
        return motors;
    }

    public void setMotors(List<Motor> motors) {
        this.motors = motors;
    }

    // Builder
    public static SellerBuilder builder() {
        return new SellerBuilder();
    }

    public static class SellerBuilder {
        private String username;
        private String password;
        private String mobileNumber;
        private String name;
        private String email;
        private String businessName;
        private String address;
        private Boolean isActive = true;

        public SellerBuilder username(String username) {
            this.username = username;
            return this;
        }

        public SellerBuilder password(String password) {
            this.password = password;
            return this;
        }

        public SellerBuilder mobileNumber(String mobileNumber) {
            this.mobileNumber = mobileNumber;
            return this;
        }

        public SellerBuilder name(String name) {
            this.name = name;
            return this;
        }

        public SellerBuilder email(String email) {
            this.email = email;
            return this;
        }

        public SellerBuilder businessName(String businessName) {
            this.businessName = businessName;
            return this;
        }

        public SellerBuilder address(String address) {
            this.address = address;
            return this;
        }

        public SellerBuilder isActive(Boolean isActive) {
            this.isActive = isActive;
            return this;
        }

        public Seller build() {
            Seller seller = new Seller();
            seller.username = this.username;
            seller.password = this.password;
            seller.mobileNumber = this.mobileNumber;
            seller.name = this.name;
            seller.email = this.email;
            seller.businessName = this.businessName;
            seller.address = this.address;
            seller.isActive = this.isActive;
            return seller;
        }
    }
}
