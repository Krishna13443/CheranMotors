package com.submotors.controller;

import com.submotors.model.Motor;
import com.submotors.model.Seller;
import com.submotors.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    // Authentication
    @PostMapping("/send-otp")
    public ResponseEntity<Map<String, Object>> sendOtp(@RequestBody Map<String, String> request) {
        String mobileNumber = request.get("mobileNumber");
        Map<String, Object> response = adminService.sendAdminOtp(mobileNumber);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<Map<String, Object>> verifyOtp(@RequestBody Map<String, String> request) {
        String mobileNumber = request.get("mobileNumber");
        String otp = request.get("otp");
        Map<String, Object> response = adminService.verifyAdminOtp(mobileNumber, otp);
        return ResponseEntity.ok(response);
    }

    // Dashboard
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard() {
        return ResponseEntity.ok(adminService.getDashboardStats());
    }

    // Seller Management
    @GetMapping("/sellers")
    public ResponseEntity<List<Seller>> getAllSellers() {
        return ResponseEntity.ok(adminService.getAllSellers());
    }

    @PostMapping("/sellers")
    public ResponseEntity<Map<String, Object>> createSeller(@RequestBody Map<String, String> sellerData) {
        return ResponseEntity.ok(adminService.createSeller(sellerData));
    }

    @PutMapping("/sellers/{id}/toggle-status")
    public ResponseEntity<Map<String, Object>> toggleSellerStatus(@PathVariable Long id) {
        return ResponseEntity.ok(adminService.toggleSellerStatus(id));
    }

    // Motor Management
    @GetMapping("/motors/pending")
    public ResponseEntity<List<Motor>> getPendingMotors() {
        return ResponseEntity.ok(adminService.getPendingMotors());
    }

    @GetMapping("/motors/{id}")
    public ResponseEntity<Map<String, Object>> getMotorDetails(@PathVariable Long id) {
        return ResponseEntity.ok(adminService.getMotorDetails(id));
    }

    @PostMapping("/motors/{id}/approve")
    public ResponseEntity<Map<String, Object>> approveMotor(@PathVariable Long id) {
        return ResponseEntity.ok(adminService.approveMotor(id));
    }

    @PostMapping("/motors/{id}/reject")
    public ResponseEntity<Map<String, Object>> rejectMotor(
            @PathVariable Long id,
            @RequestBody Map<String, String> request) {
        String reason = request.getOrDefault("reason", "Rejected by admin");
        return ResponseEntity.ok(adminService.rejectMotor(id, reason));
    }
}
