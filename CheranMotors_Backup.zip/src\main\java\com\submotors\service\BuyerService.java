package com.submotors.service;

import com.submotors.model.Buyer;
import com.submotors.model.Motor;
import com.submotors.model.OtpVerification;
import com.submotors.repository.BuyerRepository;
import com.submotors.repository.MotorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class BuyerService {

    @Autowired
    private BuyerRepository buyerRepository;

    @Autowired
    private MotorRepository motorRepository;

    @Autowired
    private OtpService otpService;

    public Map<String, Object> sendOtp(String mobileNumber) {
        return otpService.sendOtp(mobileNumber, OtpVerification.UserType.BUYER);
    }

    @Transactional
    public Map<String, Object> verifyOtpAndLogin(String mobileNumber, String otp, String name) {
        Map<String, Object> result = otpService.verifyOtp(mobileNumber, otp, OtpVerification.UserType.BUYER);

        if ((Boolean) result.get("success")) {
            // Create or update buyer
            Buyer buyer = buyerRepository.findByMobileNumber(mobileNumber)
                    .orElse(Buyer.builder()
                            .mobileNumber(mobileNumber)
                            .name(name != null ? name : "Buyer")
                            .build());

            buyer = buyerRepository.save(buyer);

            String token = UUID.randomUUID().toString();
            result.put("token", token);
            result.put("buyerId", buyer.getId());
            result.put("name", buyer.getName());
            result.put("role", "BUYER");
        }

        return result;
    }

    public List<Motor> getApprovedMotors() {
        return motorRepository.findByIsApprovedTrueOrderByCreatedAtDesc();
    }

    public List<Motor> searchMotors(String query) {
        if (query == null || query.trim().isEmpty()) {
            return getApprovedMotors();
        }
        return motorRepository.searchMotors(query.trim());
    }

    public List<Motor> filterByType(String type) {
        try {
            Motor.MotorType motorType = Motor.MotorType.valueOf(type.toUpperCase());
            return motorRepository.findByIsApprovedTrueAndMotorTypeOrderByCreatedAtDesc(motorType);
        } catch (IllegalArgumentException e) {
            return getApprovedMotors();
        }
    }

    public Optional<Motor> getMotorDetails(Long motorId) {
        return motorRepository.findById(motorId)
                .filter(Motor::getIsApproved);
    }
}
